"""Extract both autotile sizes from ONE generated mother, no foliage drawing.

Native grid is uniform. Compact quarters are integer crops, never rescaled.
Precheck is a sampling simulation, not evidence of Unity rendering.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from statistics import median
import json,sys,hashlib
root=Path(__file__).parent
src=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
plan=json.loads((root/'moss-winding-plan-r2.json').read_text())
raw=Image.open(src).convert('RGBA');im=raw.resize(tuple(plan['logicalCanvas']),Image.Resampling.NEAREST)
im.putdata([(r,g,b,0) if r>170 and b>170 and g<140 else (r,g,b,a) for r,g,b,a in im.getdata()])
# Tone correction only, using the generated core's own median color.
contrast=float(sys.argv[sys.argv.index('--soil-contrast')+1]) if '--soil-contrast' in sys.argv else .25
assert 0<=contrast<=1
soil=[(r,g,b) for r,g,b,a in im.getdata() if a and b>g and g>r]
base=tuple(int(median([c[i] for c in soil])) for i in range(3))
im.putdata([tuple(round(contrast*c+(1-contrast)*m) for c,m in zip((r,g,b),base))+(a,)
            if a and b>g and g>r else (r,g,b,a) for r,g,b,a in im.getdata()])
mask=Image.open(root/'moss-winding-mask-r2.png').convert('L')
alpha=im.getchannel('A')
def registered_offset(sample):
    k=sample['kind']
    if k=='fill':return 0,0,0
    x,y=sample['cell'];cx=x*32+16;cy=y*32+16
    points=[(px,py,mask.getpixel((px,py))>0)
            for py in range(max(0,cy-32),min(384,cy+32),3)
            for px in range(max(0,cx-32),min(384,cx+32),3)]
    offsets=[(dx,dy) for dx in range(-16,17) for dy in range(-16,17)
             if (k!='horizontal' or dx==0) and (k!='vertical' or dy==0)]
    def error(offset):
        dx,dy=offset
        valid=[(px,py,want) for px,py,want in points if 0<=px+dx<384 and 0<=py+dy<384]
        wrong=sum((alpha.getpixel((px+dx,py+dy))>127)!=want for px,py,want in valid)
        return wrong/len(valid)+(abs(dx)+abs(dy))*.00001
    dx,dy=min(offsets,key=error)
    return dx,dy,round(error((dx,dy)),5)

bank={};rects=[]
for sample in plan['samples']:
    k,q=sample['kind'],sample['imageQuadrant'];x,y,w,h=sample['wideRect']
    dx,dy,error=registered_offset(sample);x+=dx;y+=dy
    p=im.crop((x,y,x+w,y+h));bank[16,k,q]=p
    cx=(q%2)*8;cy=(q//2)*8
    bank[8,k,q]=p.crop((cx,cy,cx+8,cy+8))
    rects.append({**sample,'registeredWideRect':[x,y,16,16],
                  'registrationTranslation':[dx,dy],'maskMismatch':error,
                  'compactRect':[x+cx,y+cy,8,8]})

seam_report=None
if '--correct-compact' in sys.argv:
    for sample in rects:
        k,q=sample['kind'],sample['imageQuadrant']
        if k=='fill':continue
        x,y,_,_=sample['registeredWideRect']
        def crop_score(pos):
            dx,dy=pos;p=im.crop((x+dx,y+dy,x+dx+8,y+dy+8))
            colors=list(p.getdata());green=sum(a>0 and g>b*1.3 and g>r for r,g,b,a in colors)
            bright=sum(a>0 and r>55 and g>130 and g>b*2 for r,g,b,a in colors)
            return green+bright*.5-(abs(dx-q%2*8)+abs(dy-q//2*8))*.01
        dx,dy=max([(dx,dy) for dx in range(9) for dy in range(9)],key=crop_score)
        bank[8,k,q]=im.crop((x+dx,y+dy,x+dx+8,y+dy+8))
        sample['compactRect']=[x+dx,y+dy,8,8]
    from align_quarter_seams import align
    seam_report=align(bank)

def kind(cells,x,y,q):
    dx=-1 if q%2==0 else 1;dy=-1 if q<2 else 1
    h=(x+dx,y) in cells;v=(x,y+dy) in cells;d=(x+dx,y+dy) in cells
    return 'outer' if not h and not v else 'vertical' if not h else 'horizontal' if not v else 'fill' if d else 'inner'

def slot_quarter(slot,q):
    # Slot ordering follows GridArtRules, image quadrant ordering is top-first.
    if slot<9:
        x=slot%3;y=slot//3
        h=not((x==0 and q%2==0) or (x==2 and q%2==1))
        v=not((y==0 and q<2) or (y==2 and q>=2))
        return 'outer' if not h and not v else 'vertical' if not h else 'horizontal' if not v else 'fill'
    target=(slot-9)^2 # Unity BL/BR/TL/TR -> image TL/TR/BL/BR
    return 'inner' if q==target else 'fill'

def atlas(n):
    sheet=Image.new('RGBA',(13*n*2,n*2))
    for slot in range(13):
        for q in range(4):sheet.paste(bank[n,slot_quarter(slot,q),q],(slot*n*2+(q%2)*n,(q//2)*n))
    return sheet

compact=atlas(8);wide=atlas(16)
compact.save(out/'MossWindingCompactRaw.png');wide.save(out/'MossWindingWideRaw.png')
im.save(out/'MossWindingMotherNative384.png')

def render(cells,n=8):
    xmin=min(x for x,y in cells);ymin=min(y for x,y in cells);xmax=max(x for x,y in cells);ymax=max(y for x,y in cells)
    result=Image.new('RGBA',((xmax-xmin+3)*n*2,(ymax-ymin+3)*n*2),'#192b38')
    for x,y in cells:
        for q in range(4):result.alpha_composite(bank[n,kind(cells,x,y,q),q],((x-xmin+1)*n*2+(q%2)*n,(y-ymin+1)*n*2+(q//2)*n))
    return result

# Exactly 47 legal masks: a diagonal is relevant only if BOTH cardinals exist.
offsets=[(-1,-1),(0,-1),(1,-1),(-1,0),(1,0),(-1,1),(0,1),(1,1)]
legal={}
for bits in range(256):
    cells={(0,0)}|{p for i,p in enumerate(offsets) if bits>>i&1}
    norm=frozenset(p for p in cells if p==(0,0) or p[0]==0 or p[1]==0 or ((p[0],0) in cells and (0,p[1]) in cells))
    legal[norm]=tuple(kind(norm,0,0,q) for q in range(4))
assert len(legal)==47 and len(set(legal.values()))==47
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',14)
qa=Image.new('RGBA',(768,570),'#121c27');d=ImageDraw.Draw(qa)
d.text((16,8),'同一弯曲母图 → 47种邻接采样预检（非Unity）',font=font,fill='white')
for i,states in enumerate(legal.values()):
    tile=Image.new('RGBA',(16,16))
    for q,k in enumerate(states):tile.paste(bank[8,k,q],((q%2)*8,(q//2)*8))
    tile=tile.resize((48,48),Image.Resampling.NEAREST);x=16+(i%12)*62;y=40+(i//12)*72
    qa.alpha_composite(tile,(x,y));d.text((x,y+49),str(i+1),font=font,fill='#acb8c6')
rect=lambda w,h:{(x,y) for x in range(w) for y in range(h)}
shapes=[('实心',rect(8,4)),('单格横条',rect(8,1)),('单格竖条',rect(1,6)),
        ('孔洞',rect(8,6)-{(x,y) for x in range(2,6) for y in range(2,4)}),
        ('L',{(x,y) for x,y in rect(7,5) if x<2 or y>2}),
        ('T',{(x,y) for x,y in rect(7,5) if y<2 or 2<=x<=3}),
        ('十字',{(x,y) for x,y in rect(7,7) if x in (2,3) or y in (2,3)}),
        ('阶梯',{(x,y) for x,y in rect(8,5) if y>=x//2}),
        ('斜角与孤岛',{(0,0),(1,1),(2,2),(4,1)}),
        ('负坐标', {(x-6,y-9) for x,y in rect(6,4) if not(x==3 and y==2)})]
connections=Image.new('RGBA',(960,800),'#121c27');d2=ImageDraw.Draw(connections)
for i,(name,cells) in enumerate(shapes):
    x=(i%5)*192;y=30+(i//5)*280
    d2.text((x+8,y),name,font=font,fill='white');p=render(cells)
    scale=min(2,180//p.width,230//p.height)
    connections.alpha_composite(p.resize((p.width*scale,p.height*scale),Image.Resampling.NEAREST),(x+8,y+30))
d2.text((8,610),'原生16px/格；下方为32px源直接采样，尚非GridArt宽轮廓渲染',font=font,fill='white')
p=render(rect(10,4),16);connections.alpha_composite(p,(8,640))
connections.save(out/'MossWindingConnectionsRaw.png');qa.save(out/'MossWinding47Raw.png')
manifest={'source':src.name,'sourceSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),
          'rawSize':raw.size,'logicalSize':im.size,'coreMedian':base,
          'processing':['uniform nearest resize to logical384','magenta key',f'core contrast {contrast:.0%} around generated median',
                        'local alpha-mask translation registration (no scaling/rotation)',
                        'integer quarter crops at single native scale','assemble existing 13-slot contract'],
          'quarterSamples':rects,'legalNeighborStates':47,'compactSeamAlignment':seam_report,'artApproved':False,'unityImported':False,
          'limitations':['Integer crops; compact boundary profiles aligned only when requested, wide phase still uncorrected.',
                         'Wide precheck is ordinary32px sampling, not GridArtWideContour.',
                         'Open-port caps in source excluded from selected samples.']}
(out/'extraction.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'logicalCanvas':im.size,'legalMasks':len(legal),'sourceSize':raw.size,'artApproved':False}))
