"""Candidate-only texture edge correction for the existing Unity sampling path.

Uses saved lab maps and a literal port of GridArtWideContour.Resolve. This is
not independent proof of that renderer; final candidates require GPU capture.
Only generated pixels are averaged/decontaminated, no foliage is synthesized.
"""
from pathlib import Path
from PIL import Image
from statistics import mean
import json,re,sys,hashlib,shutil
from align_quarter_seams import DSU

src,out,lab,code=map(Path,sys.argv[1:5]);out.mkdir(parents=True,exist_ok=False)
atlases={k:Image.open(src/name).convert('RGBA') for k,name in
         [('c','MossWindingCompactRaw.png'),('w','MossWindingWideRaw.png')]}
original={k:im.copy() for k,im in atlases.items()}
fringe=0
for im in atlases.values():
    previous=im.copy()
    bad=lambda c:c[3]>0 and c[0]>50 and c[2]>50 and c[0]>c[1]*1.4 and c[2]>c[1]*1.4
    for y in range(im.height):
        for x in range(im.width):
            if not bad(previous.getpixel((x,y))):continue
            nearby=[previous.getpixel((xx,yy)) for yy in range(max(0,y-2),min(im.height,y+3))
                    for xx in range(max(0,x-2),min(im.width,x+3))
                    if previous.getpixel((xx,yy))[3]>0 and not bad(previous.getpixel((xx,yy)))]
            if nearby:
                color=min(nearby,key=lambda c:sum(abs(c[i]-previous.getpixel((x,y))[i]) for i in range(3)))
                im.putpixel((x,y),color)
            else:im.putpixel((x,y),(0,0,0,0))
            fringe+=1

if '--decontam-only' in sys.argv:
    for k,name in [('c','MossWindingCompactRaw.png'),('w','MossWindingWideRaw.png')]:atlases[k].save(out/name)
    shutil.copy2(src/'MossWindingMotherNative384.png',out/'MossWindingMotherNative384.png')
    report={'sourceExtractionSHA256':hashlib.sha256((src/'extraction.json').read_bytes()).hexdigest(),
            'magentaDecontaminatedAtlasPixels':fringe,'method':'Local color decontamination only; no boundary unification.',
            'artApproved':False,'unityImported':False,'limitations':['Wide/compact transition still needs art review.']}
    (out/'decontamination.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report));sys.exit()

def slot(c,p,q):
    x,y=p;dx=-1 if q%2==0 else 1;dy=-1 if q<2 else 1
    h=(x+dx,y) in c;v=(x,y+dy) in c;d=(x+dx,y+dy) in c
    xx=0 if q%2==0 else 2;yy=2 if q<2 else 0
    return yy*3+xx if not h and not v else 3+xx if not h else yy*3+1 if not v else 4 if d else 9+q

def resolve(c,p,q):
    x,y=p
    def air(dx,dy):
        for distance in [1,2]:
            if (x+dx*distance,y+dy*distance) not in c:return distance
        return 0
    left,right,bottom,top=air(-1,0),air(1,0),air(0,-1),air(0,1)
    qx,qy=q%2,q//2
    if (left==1 and right==1) or (top==1 and bottom==1):return ('c',slot(c,p,q),qx,1-qy)
    cx,cy=qx*.5+.25,qy*.5+.25
    useLeft=left>0 and (right==0 or left-1+cx<=right-cx)
    useBottom=bottom>0 and (top==0 or bottom-1+cy<=top-cy)
    horizontal=left if useLeft else right;vertical=bottom if useBottom else top
    sx=x%2*16+qx*8;sy=y%2*16+qy*8;s=4
    if horizontal>0:sx=(left-1)*16+qx*8 if useLeft else 32-right*16+qx*8
    if vertical>0:sy=(bottom-1)*16+qy*8 if useBottom else 32-top*16+qy*8
    if horizontal>0 and vertical>0:s=(2 if useBottom else 0)*3+(0 if useLeft else 2)
    elif horizontal>0:s=3 if useLeft else 5
    elif vertical>0:s=7 if useBottom else 1
    cardinal=min([distance for ok,distance in
                  [(left>0,left-1+cx),(right>0,right-cx),(bottom>0,bottom-1+cy),(top>0,top-cy)] if ok] or [float('inf')])
    nearest=cardinal*cardinal
    for dy in range(-2,3):
        for dx in range(-2,3):
            if dx==0 or dy==0 or (x+dx,y+dy) in c:continue
            xx=-dx-1+cx if dx<0 else dx-cx;yy=-dy-1+cy if dy<0 else dy-cy
            distance=xx*xx+yy*yy
            if distance>=nearest:continue
            nearest=distance;s=9+(0 if dx<0 else 1)+(0 if dy<0 else 2)
            sx=(-dx-1)*16+qx*8 if dx<0 else 32-dx*16+qx*8
            sy=(-dy-1)*16+qy*8 if dy<0 else 32-dy*16+qy*8
    assert 0<=sx<=24 and 0<=sy<=24
    return ('w',s,sx//8,3-sy//8)

patches={};pairs=set();map_info=[]
for path in sorted(lab.glob('*Map.asset')):
    layers=re.split(r'^  - id: ',path.read_text(encoding='utf-8'),flags=re.M)[1:]
    counts=[]
    for layer in layers:
        cells={(int(x),int(y)) for x,y in re.findall(r'    - position: \{x: (-?\d+), y: (-?\d+)\}\n      brush: 0\n',layer)}
        counts.append(len(cells));used={}
        for p in cells:
            for q in range(4):
                key=resolve(cells,p,q);used[(p[0]*2+q%2,-p[1]*2+1-q//2)]=key
                if key not in patches:
                    k,s,ix,iy=key;n=16 if k=='c' else 32
                    patches[key]=atlases[k].crop((s*n+ix*8,iy*8,s*n+ix*8+8,iy*8+8))
        for (x,y),key in used.items():
            for pos,side,other in [((x+1,y),1,0),((x,y+1),3,2)]:
                if pos in used:pairs.add(((key,side),(used[pos],other)))
    map_info.append({'name':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'brush0CellsPerLayer':counts})

def xy(side,i):return [(0,i),(7,i),(i,0),(i,7)][side]
dsu=DSU()
for a,b in sorted(pairs):
    for i in range(8):dsu.join((a[0],*xy(a[1],i)),(b[0],*xy(b[1],i)))
groups={}
for node in list(dsu.p):groups.setdefault(dsu.get(node),[]).append(node)
def avg(colors):
    alpha=mean(c[3] for c in colors)
    return tuple(round(mean(c[i]*c[3]/255 for c in colors)*255/alpha) if alpha else 0 for i in range(3))+(round(alpha),)
values={}
for nodes in groups.values():
    # Genuine interior samples dominate interior continuations, preventing green
    # rectangular grids from being averaged into otherwise solid soil.
    donors=[node for node in nodes if node[0][1]==4] or nodes
    color=avg([patches[key].getpixel((x,y)) for key,x,y in donors])
    for node in nodes:values[node]=color
before=[abs(patches[a[0]].getpixel(xy(a[1],i))[channel]-patches[b[0]].getpixel(xy(b[1],i))[channel])
        for a,b in pairs for i in range(8) for channel in range(4)]
changes=0
for key,patch in patches.items():
    corrected=patch.copy()
    for y in range(8):
        for x in range(8):
            if (key,x,y) in values:corrected.putpixel((x,y),values[key,x,y]);continue
            neighbors=[]
            for edge in [(0,y) if x==1 else None,(7,y) if x==6 else None,
                         (x,0) if y==1 else None,(x,7) if y==6 else None]:
                if edge and (key,*edge) in values:neighbors.append(values[(key,*edge)])
            if neighbors:corrected.putpixel((x,y),avg([patch.getpixel((x,y))]*3+neighbors))
    changes+=sum(a!=b for a,b in zip(patch.getdata(),corrected.getdata()))
    patches[key]=corrected
after=[abs(patches[a[0]].getpixel(xy(a[1],i))[channel]-patches[b[0]].getpixel(xy(b[1],i))[channel])
       for a,b in pairs for i in range(8) for channel in range(4)]
assert max(after)==0
for (k,s,ix,iy),patch in patches.items():atlases[k].paste(patch,(s*(16 if k=='c' else 32)+ix*8,iy*8))
for k,name in [('c','MossWindingCompactRaw.png'),('w','MossWindingWideRaw.png')]:atlases[k].save(out/name)
shutil.copy2(src/'MossWindingMotherNative384.png',out/'MossWindingMotherNative384.png')
report={'sourceExtractionSHA256':hashlib.sha256((src/'extraction.json').read_bytes()).hexdigest(),
        'unitySamplingCodeSHA256':hashlib.sha256(code.read_bytes()).hexdigest(),
        'maps':map_info,'sampledPatchCount':len(patches),'compatibleEdgePairs':len(pairs),'pixelClasses':len(groups),
        'beforeMeanRGBA':round(mean(before),3),'beforeMaxRGBA':max(before),'afterMaxRGBA':max(after),
        'changedPatchPixels':changes,'magentaDecontaminatedAtlasPixels':fringe,
        'method':'Sample-dependent premultiplied boundary correction, generated pixels only, one-pixel inward feather.',
        'artApproved':False,'unityImported':False,
        'limitations':['Bounded to listed maps, not exhaustive wide-distance/parity configurations.',
                       'Renderer port and edge equality are not independent art or GPU approval.']}
(out/'unity-sampling-alignment.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['maps','limitations']},indent=2))
