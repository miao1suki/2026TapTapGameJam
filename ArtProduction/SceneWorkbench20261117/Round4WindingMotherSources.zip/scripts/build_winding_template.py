"""Structural mask and extraction contract, never shipped as terrain artwork."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json

ROOT = Path(__file__).parent
UNIT = 32
SIZE = 12 * UNIT
# One connected winding terrain. Four arms leave the canvas; none is capped.
# The staggered bends provide convex AND concave corners in all orientations.
POLYGON = [(4,0),(8,0),(8,2),(12,2),(12,6),(10,6),(10,10),
           (8,10),(8,12),(4,12),(4,10),(6,10),(6,8),(2,8),
           (2,6),(0,6),(0,2),(2,2),(2,4),(4,4)]
mask = Image.new('L', (SIZE,SIZE))
ImageDraw.Draw(mask).polygon([(x*UNIT,y*UNIT) for x,y in POLYGON], fill=255)
cells = {(x,y) for y in range(12) for x in range(12)
         if mask.getpixel((x*UNIT+16,y*UNIT+16))}
mask = Image.new('L',(SIZE,SIZE))
md = ImageDraw.Draw(mask)
for x,y in cells: md.rectangle((x*UNIT,y*UNIT,(x+1)*UNIT-1,(y+1)*UNIT-1), fill=255)
def kind(x,y,q):
    dx=-1 if q%2==0 else 1
    dy=-1 if q<2 else 1 # image coordinates: TL, TR, BL, BR
    h=(x+dx,y) in cells; v=(x,y+dy) in cells; d=(x+dx,y+dy) in cells
    return 'outer' if not h and not v else 'vertical' if not h else 'horizontal' if not v else 'fill' if d else 'inner'
samples=[]
for q in range(4):
    for k in ['outer','vertical','horizontal','inner','fill']:
        candidates=[(x,y) for x,y in sorted(cells) if kind(x,y,q)==k
                    and 0<x<11 and 0<y<11]
        if not candidates: raise ValueError(f'Missing {k} orientation {q}')
        # Prefer candidates away from the canvas ports, deterministic on ties.
        x,y=max(candidates,key=lambda p:min(p[0],p[1],11-p[0],11-p[1]))
        samples.append({'kind':k,'imageQuadrant':q,'cell':[x,y],
                        'wideRect':[x*UNIT+(q%2)*16,y*UNIT+(q//2)*16,16,16]})
seen=set(); todo=[next(iter(cells))]
while todo:
    p=todo.pop()
    if p in seen: continue
    seen.add(p)
    todo.extend((p[0]+dx,p[1]+dy) for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]
                if (p[0]+dx,p[1]+dy) in cells)
assert seen==cells
assert all(any((x,y) in cells for x,y in edge) for edge in
           [[(x,0) for x in range(12)],[(x,11) for x in range(12)],
            [(0,y) for y in range(12)],[(11,y) for y in range(12)]])
guide=Image.new('RGB',(SIZE,SIZE),'#ff00ff'); guide.paste('#203f4c',mask=mask)
guide.resize((1024,1024),Image.Resampling.NEAREST).save(ROOT/'moss-winding-guide-r2.png')
mask.save(ROOT/'moss-winding-mask-r2.png')
plan={'schema':'winding-mother-quarter-basis-v1','logicalCanvas':[SIZE,SIZE],
      'sourceCellPixels':UNIT,'polygon':POLYGON,'occupiedCells':sorted(cells),
      'samples':samples,'checks':{'oneConnectedComponent':True,'fourOpenPorts':True,
      'allFiveQuarterStatesInAllFourOrientations':True},
      'notes':['Geometry reference only; not a style reference or game asset.',
               'One uniform source scale for 8px compact and 16px wide quarters.',
               'Artwork drift and texture seams still require validation.']}
(ROOT/'moss-winding-plan-r2.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
preview=guide.resize((576,576),Image.Resampling.NEAREST)
d=ImageDraw.Draw(preview);font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',13)
for s in samples:
    x,y,w,h=s['wideRect']; rect=(x*1.5,y*1.5,(x+w)*1.5,(y+h)*1.5)
    d.rectangle(rect,outline='#ffffff',width=1)
    d.text((rect[0],rect[1]),s['kind'][0]+str(s['imageQuadrant']),font=font,fill='white')
preview.save(ROOT/'moss-winding-plan-preview-r2.png')
print(json.dumps(plan['checks']))
