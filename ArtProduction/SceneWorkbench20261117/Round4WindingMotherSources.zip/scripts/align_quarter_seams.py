"""Join compatible generated-pixel edges. Never synthesize foliage shapes."""
from statistics import mean
from PIL import Image

KINDS=['outer','vertical','horizontal','inner','fill']
class DSU:
    def __init__(self):self.p={}
    def get(self,a):
        self.p.setdefault(a,a)
        if self.p[a]!=a:self.p[a]=self.get(self.p[a])
        return self.p[a]
    def join(self,a,b):self.p[self.get(a)]=self.get(b)

def kind(cells,x,y,q):
    dx=-1 if q%2==0 else 1;dy=-1 if q<2 else 1
    h=(x+dx,y) in cells;v=(x,y+dy) in cells;d=(x+dx,y+dy) in cells
    return 'outer' if not h and not v else 'vertical' if not h else 'horizontal' if not v else 'fill' if d else 'inner'

def align(bank,n=8):
    keys=[(n,k,q) for k in KINDS for q in range(4)]
    pairs=set()
    def pair(cells,a,aq,ae,b,bq,be):
        ak=(n,kind(cells,*a,aq),aq);bk=(n,kind(cells,*b,bq),bq)
        pairs.add(((ak,ae),(bk,be)))
    # Internal center seams, every 3x3 neighborhood.
    neighbors=[(x,y) for y in range(-1,2) for x in range(-1,2) if (x,y)!=(0,0)]
    for bits in range(256):
        cells={(0,0)}|{p for i,p in enumerate(neighbors) if bits>>i&1}
        for q in [0,2]:pair(cells,(0,0),q,1,(0,0),q+1,0)
        for q in [0,1]:pair(cells,(0,0),q,3,(0,0),q+2,2)
    # Two adjacent occupied cells require a 4x3 (or 3x4) neighborhood.
    for vertical in [False,True]:
        w,h=(3,4) if vertical else (4,3)
        a=(1,1);b=(1,2) if vertical else (2,1)
        others=[(x,y) for y in range(h) for x in range(w) if (x,y) not in [a,b]]
        for bits in range(1<<len(others)):
            cells={a,b}|{p for i,p in enumerate(others) if bits>>i&1}
            if vertical:
                pair(cells,a,2,3,b,0,2);pair(cells,a,3,3,b,1,2)
            else:
                pair(cells,a,1,1,b,0,0);pair(cells,a,3,1,b,2,0)
    edges=DSU();corners=DSU()
    endpoints={0:[0,2],1:[1,3],2:[0,1],3:[2,3]}
    for a,b in pairs:
        edges.join(a,b)
        for ca,cb in zip(endpoints[a[1]],endpoints[b[1]]):corners.join((a[0],ca),(b[0],cb))
    def xy(side,i):return [(0,i),(n-1,i),(i,0),(i,n-1)][side]
    def avg(values):
        # Premultiplied averaging avoids magenta fringes in transparent samples.
        alpha=mean(c[3] for c in values)
        return tuple(round(mean(c[i]*c[3]/255 for c in values)*255/alpha) if alpha else 0 for i in range(3))+(round(alpha),)
    groups={};cg={}
    for key in keys:
        for side in range(4):
            node=(key,side)
            if node in edges.p:groups.setdefault(edges.get(node),[]).append(node)
        for c in range(4):
            node=(key,c)
            if node in corners.p:cg.setdefault(corners.get(node),[]).append(node)
    def donors(nodes):
        # Interior continuations must stay core-colored. Averaging thick moss
        # into a fill seam creates an artificial green grid over solid terrain.
        fill=[node for node in nodes if node[0][1]=='fill']
        return fill or nodes
    cv={r:avg([bank[key].getpixel(((c%2)*(n-1),(c//2)*(n-1))) for key,c in donors(nodes)]) for r,nodes in cg.items()}
    profiles={}
    for r,nodes in groups.items():
        p=[avg([bank[key].getpixel(xy(side,i)) for key,side in donors(nodes)]) for i in range(n)]
        key,side=nodes[0]
        p[0]=cv[corners.get((key,endpoints[side][0]))];p[-1]=cv[corners.get((key,endpoints[side][1]))]
        for node in nodes:profiles[node]=p
    before=[abs(bank[a[0]].getpixel(xy(a[1],i))[c]-bank[b[0]].getpixel(xy(b[1],i))[c])
            for a,b in pairs for i in range(n) for c in range(4)]
    for key in keys:
        source=bank[key];dst=source.copy()
        for y in range(n):
            for x in range(n):
                hits=[]
                for side,dist,t in [(0,x,y),(1,n-1-x,y),(2,y,x),(3,n-1-y,x)]:
                    if dist<2 and (key,side) in profiles:hits.append((dist,profiles[key,side][t]))
                if not hits:continue
                zero=[color for dist,color in hits if dist==0]
                color=avg(zero) if zero else avg([source.getpixel((x,y))]*2+[color for dist,color in hits])
                dst.putpixel((x,y),color)
        bank[key]=dst
    after=[abs(bank[a[0]].getpixel(xy(a[1],i))[c]-bank[b[0]].getpixel(xy(b[1],i))[c])
           for a,b in pairs for i in range(n) for c in range(4)]
    assert max(after)==0
    return {'compatibleEdgePairs':len(pairs),'edgeClasses':len(groups),
            'beforeMeanRGBA':round(mean(before),3),'beforeMaxRGBA':max(before),
            'afterMaxRGBA':max(after),'featherPixels':1,
            'note':'Constrained edge equality, not independent art or Unity approval.'}
