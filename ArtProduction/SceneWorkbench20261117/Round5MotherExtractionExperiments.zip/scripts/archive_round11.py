from pathlib import Path
from PIL import Image
import hashlib,json,zipfile,xml.etree.ElementTree as ET,subprocess

repo=Path('C:/Users/miao/.codex/worktrees/scene-authoring-redesign/2026TapTap')
task=Path(__file__).resolve().parent.parent;art=task/'work/art';outputs=task/'outputs'
production=repo/'ArtProduction/SceneWorkbench20261117'
evidence=repo/'Docs/Developer/Evidence/SceneWorkbench20261117/Round11'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
items=[]
def add(path,name):
    assert path.is_file(),path
    items.append((path,name))
for stem in ['moss-native16-mother-r4','moss-winding-mother-r3']:
    for suffix in ['.png','.txt','.png.request.json']:add(art/(stem+suffix),'sources/'+stem+suffix)
for name in ['extract_winding_mother.py','extract_native16_mother.py','align_quarter_seams.py','align_unity_sampling.py',
             'build_native16_template.py','check_winding_topology.py','moss-native16-guide-r4.png','moss-native16-mask-r4.png',
             'moss-native16-plan-r4.json','moss-winding-plan-r2.json','moss-winding-mask-r2.png',
             'winding-native16-design-r4.txt','native16-unity-review-r4.txt']:
    add(art/name,('scripts/' if name.endswith('.py') else 'inputs/')+name)
reviews=Path('C:/Users/miao/AppData/Local/XingZhiCai/ArtWorkflow/reviews')
add(Path(__file__),'scripts/archive_round11.py')
for name in ['20261118-153134-362','20261118-160537-611']:
    data=json.loads((reviews/(name+'.json')).read_text(encoding='utf-8-sig'))
    assert data['reviewComplete']
    add(reviews/(name+'.json'),'reviews/'+name+'.json')
candidates={
 'r3e':('winding-mother-r3e','WindingMotherLabR3e','Rejected: fixed compact crop loses material on isolated/narrow shapes.'),
 'r4-raw':('native16-mother-r4','WindingMotherLabR4c','Claude REWORK: thin uniform rim and repeated soil dots.'),
 'r4-limit-rim':('native16-mother-r4b','WindingMotherLabR4','Rejected: clipping moss to core makes the rim even thinner.'),
 'r5-single-bank':('winding-r3-singlebank-r5','WindingMotherLabR5','Rejected: downsamples r3 into one compact bank but loses lush rim thickness.'),
 'r5b-wide-only':('winding-r3-wideonly-r5b','WindingMotherLabR5b','Rejected: removing compact fallback loses narrow strips/isolated art.'),
 'r5c-wide-inset':('winding-r3-wideinset-r5c','WindingMotherLabR5c','Rejected: source inset restores some narrow material but joins/isolated silhouettes remain poor.')}
names=['MossWindingCompactRaw.png','MossWindingWideRaw.png','extraction.json','decontamination.json',
       'UnityAqueduct.png','UnityConnections.png','UnityAll47.png','UnityAqueductPreview.png','UnityConnectionsPreview.png',
       'GridArtWideContourExperiment.cs.txt']
for key,(folder,lab,status) in candidates.items():
    for name in names:
        path=outputs/folder/name
        if path.is_file():add(path,'candidates/'+key+'/'+name)
    source=repo/'Library'/lab/'result.txt'
    if source.is_file():add(source,'candidates/'+key+'/unity-result.txt')
add(outputs/'winding-mother-r3e-source/extraction.json','candidates/r3e/source-extraction.json')
for name in ['Native16Comparison.png','WideOnlySamplingComparison.png','winding-topology-validation.json']:
    add(outputs/name,'verification/'+name)
report={'schema':'winding-mother-followup-v1','unity':'6000.3.12f1',
 'referenceScope':'Two user images constrain topology and layout only. Moss/navy style retained.',
 'motherWorkflow':'One generated continuous mother -> local registration/key/crop/edge processing -> existing 13-slot quarter contract -> actual Unity GPU scenes.',
 'sourceR4':'Generated before context compaction; reused here. No paid image generation in this continuation.',
 'candidates':{key:{'folder':folder,'lab':lab,'status':status,'artApproved':False} for key,(folder,lab,status) in candidates.items()},
 'retainedCandidate':'r3d remains unapproved progress candidate. Committed showcase is unchanged.',
 'samplingExperiments':'r5b/r5c altered only an isolated experiment version of GridArtWideContour. Production file restored exactly; neither experiment is shipped as renderer behavior.',
 'sourceGrid':'Generated PNGs are 1254x1254. 384/192 are uniform nearest-neighbor processing targets, not verified generator-native pixels or export scales.',
 'reproduction':[
  'Keep scripts and inputs together. Native16 extraction requires moss-native16-plan-r4.json and mask next to the extractor.',
  'python extract_native16_mother.py <moss-native16-mother-r4.png> <fresh-output> --align',
  'python extract_native16_mother.py <moss-native16-mother-r4.png> <fresh-output> --align --limit-rim (rejected clipping variant)',
  'python extract_native16_mother.py <moss-winding-mother-r3.png> <fresh-output> --align (r5 rejected single bank)',
  'Unity -batchmode -projectPath <project> -executeMethod Project.LevelEditor.Editor.SceneWorkbenchWindingLab.CreateFromCommandLine -windingArtInput <fresh-output> -windingLabName WindingMotherLabR6 -compactOnly -logFile <log>. Requires a fresh candidate folder.',
  'For r3e use extract_winding_mother.py with --align-compact --soil-contrast 1, then align_unity_sampling.py --decontam-only as in Round4. Its pre-decontamination extraction metadata is source-extraction.json.',
  'Experimental r5c renderer snapshot is archived as text, not imported C#. r5b is the same experiment without the two final narrow-axis inset lines. Use only in an isolated experiment checkout; restore production code afterward.'],
 'limits':['No candidate is art-approved. Geometry and seam equality do not prove visual quality.',
 'Extraction manifests were saved before import. Their unityImported:false is historical; actual GPU runs are listed in this report.',
 'Native16 rim-limited historical GPU output survives as reduced previews; its Library originals were removed by worktree archival. Do not treat previews as full-resolution proof.',
 'Candidate lab Scene/Map/Ownership/Palette copies stay local; the explicit helper reproduces new editable labs. Formal Gaming is unchanged.']}
manifest={name:{'sha256':sha(path),'bytes':path.stat().st_size} for path,name in items}
archive=production/'Round5MotherExtractionExperiments.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path,name in items:z.write(path,name)
    z.writestr('CandidateRuns.json',json.dumps(report,indent=2)+'\n')
    z.writestr('Manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,info in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256']
(production/'Round5Provenance.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive),
    'hashedInputs':len(items),'status':'All new candidates rejected; retained unapproved r3d; original showcase unchanged.',
    'topologyValidation':json.loads((outputs/'winding-topology-validation.json').read_text()),
    'native16Review':'20261118-160537-611: REWORK','sourceDetails':'CandidateRuns.json and Manifest.json in archive'},indent=2)+'\n')
print(json.dumps({'archive':archive.name,'bytes':archive.stat().st_size,'hashedInputs':len(items),'verified':True}))

full=ET.parse(task/'work/ui-art-tests-r33.xml').getroot()
assert full.attrib['passed']=='148' and full.attrib['failed']=='0'
assert ET.parse(task/'work/ui-tests-r32.xml').getroot().attrib['passed']=='22'
formal={
 'Assets/_Project/Scenes/Playing/Gaming.unity':'16acab3b7a0b828b4dc6b41387f1ecd918bfbfa46254c2b6170018d189e7a324',
 'Assets/_Project/Scenes/Playing/Gaming_Art.asset':'62172b600b200d47abc5c5cebc2e03cd35c40aff12fa60da262b3a21204d688d',
 'Assets/_Project/Scenes/Playing/Gaming.planning.json':'5714d40118dd1109d0f56f80dd6dd9ccd9a0b622a93867bba27f200e37ea3c90',
 'Assets/_Project/Content/LevelMaps/正式关卡.json':'5714d40118dd1109d0f56f80dd6dd9ccd9a0b622a93867bba27f200e37ea3c90'}
for name,expected in formal.items():assert sha(repo/name)==expected,name
protected=['Packages','ProjectSettings','Assets/_Project/Development/LevelEditor/SceneAuthoringShowcase',
           'Assets/_Project/Code/Systems/GridArt/Editor/GridArtWideContour.cs']
subprocess.run(['git','diff','--exit-code','--']+protected,cwd=repo,check=True,capture_output=True)
codepaths=['Assets/_Project/Development/LevelEditor/Orpheus0829/Editor/'+name for name in
           ['SceneLevelEditorOverlay.cs','SceneWorkbenchAudit.cs','SceneWorkbenchWindingLab.cs','SceneWorkbenchInput.cs']]
codepaths+=['Assets/_Project/Development/LevelEditor/SceneAuthoringTests/SceneWorkbenchTests.cs']
evidence.mkdir(parents=True,exist_ok=True)
eitems=[]
for name in ['ui-art-tests-r22.xml','ui-tests-r23.xml','ui-tests-r24.xml','ui-tests-r25.xml','ui-click-r26.xml',
             'ui-tests-r27.xml','ui-click-r28.xml','ui-click-r29.xml','ui-art-tests-r30.xml','ui-click-r31.xml',
             'ui-tests-r32.xml','ui-art-tests-r33.xml']:
    eitems.append((task/'work'/name,'tests/'+name))
for name in ['B-after-enable.jpg','B-visible.jpg','V-visible.jpg','Paint-click-visible.jpg','native-observer.txt']:
    eitems.append((outputs/'ui-r11'/name,'native-ui/'+name))
eitems.append((outputs/'winding-topology-validation.json','topology-validation.json'))
with zipfile.ZipFile(evidence/'verification.zip','w',zipfile.ZIP_DEFLATED) as z:
    for path,name in eitems:z.write(path,name)
    z.writestr('Manifest.json',json.dumps({name:{'sha256':sha(path),'bytes':path.stat().st_size} for path,name in eitems},indent=2)+'\n')
with zipfile.ZipFile(evidence/'verification.zip') as z:assert z.testzip() is None
validation={'unity':'6000.3.12f1','tests':{k:full.attrib[k] for k in ['total','passed','failed','skipped','duration']},
 'sourceSHA256':{name:sha(repo/name) for name in codepaths},'formalSHA256':formal,'protectedPathsUnchanged':protected,
 'nativeUIRound11':{'BWithButtonFocus':'passed','V':'passed','paintButtonClick':'passed',
  'observer':'sceneDirty=False; objects=368; mapDirty=False; revision=3; cells=388; mapHash=cca62cbc0ce9f8eee74711a2d0dfe5ed',
  'tooltip':'Native tooltip visibly covered toolbar. Removed redundant tooltip after this foreground run.',
  'limit':'Native screenshots precede tooltip removal. No native post-removal check or Undo-stack snapshot was recorded.'},
 'sceneClickIsolation':'SceneView.SendEvent: content center/corners/header strip do not stage object strokes; canvas control does. No MouseUp/author commit. Actual Undo records/cursor unchanged after settling fixture selection.',
 'testHarnessFailures':{'r24-r28':'Replacing Event.current inside Repaint gave Ignore on the positive control. Not a product regression.',
  'r29':'SceneView.SendEvent positive control passed; old current-group equality rejected native MouseDown group advance.',
  'r30-r31':'Actual history check exposed the test fixture selecting its sample before baseline. The selection record was confirmed in diagnostic XML.',
  'r32':'Fixture selection settled before workbench baseline; 22/22 passed.',
  'r33':'Full related 148/148 passed with saved-showcase contract.'},
 'showcaseSavedContract':{'objects':368,'terrainCollisionCells':366,'artLayers':6,'artAnchors':387,
  'realDoorButtonBidirectionalReferences':True,'terrainOwnershipComplete':True,'missingScripts':0,
  'authorFilesDirtyOrRewritten':False,'undoHistoryUnchanged':True,'playableLevel':False},
 'archiveRecovery':'Restored same path/branch and snapshot 4b4af20a9c88c3034026d502ce53ec391335e72b after interrupted app archive removed checkout. Ignored Library cache was rebuilt.',
 'artStatus':'All follow-up extraction/sampling candidates remain rejected; r3d retained as unapproved progress; original showcase unchanged.',
 'notVerified':['Full native mechanism binding journey','Light theme','Domain reload session journey',
                'Native click isolation across every mode','Art seams approval','Playthrough or Android/build'],
 'verificationZipSHA256':sha(evidence/'verification.zip')}
(evidence/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({'relatedPassed':148,'formalUnchanged':True,'evidenceBytes':(evidence/'verification.zip').stat().st_size}))
