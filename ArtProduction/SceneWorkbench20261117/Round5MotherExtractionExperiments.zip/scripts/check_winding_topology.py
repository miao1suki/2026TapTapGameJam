"""Validate the mother's geometric contract independently of its painted style.

This checks the guide/sample plan and normalized quarter-state combinatorics.
It does not claim that a generated silhouette or a GPU image passes art review.
"""
from pathlib import Path
from collections import deque
import hashlib,json,sys

plan_path=Path(sys.argv[1]);out=Path(sys.argv[2])
p=json.loads(plan_path.read_text());cells={tuple(c) for c in p['occupiedCells']}
remaining=set(cells);components=[]
while remaining:
    todo=deque([remaining.pop()]);size=0
    while todo:
        x,y=todo.popleft();size+=1
        for point in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
            if point in remaining:remaining.remove(point);todo.append(point)
    components.append(size)
assert len(components)==1
width,height=[v//p['sourceCellPixels'] for v in p['logicalCanvas']]
ports={'top':sorted(x for x,y in cells if y==0),'bottom':sorted(x for x,y in cells if y==height-1),
       'left':sorted(y for x,y in cells if x==0),'right':sorted(y for x,y in cells if x==width-1)}
assert all(v and v==list(range(min(v),max(v)+1)) for v in ports.values())

def kind(c,x,y,q):
    dx=-1 if q%2==0 else 1;dy=-1 if q<2 else 1
    h=(x+dx,y) in c;v=(x,y+dy) in c;d=(x+dx,y+dy) in c
    return 'outer' if not h and not v else 'vertical' if not h else 'horizontal' if not v else 'fill' if d else 'inner'

keys=set()
for s in p['samples']:
    q=s['imageQuadrant'];x,y=s['cell']
    assert (x,y) in cells
    assert kind(cells,x,y,q)==s['kind'],s
    assert (s['kind'],q) not in keys
    keys.add((s['kind'],q))
assert keys=={(k,q) for k in ['outer','vertical','horizontal','inner','fill'] for q in range(4)}
neighbors=[(x,y) for y in [-1,0,1] for x in [-1,0,1] if x or y]
normalized={};unreachable=[]
for bits in range(256):
    c={(0,0)}|{v for i,v in enumerate(neighbors) if bits>>i&1}
    n=frozenset(v for v in c if v==(0,0) or not(v[0] and v[1]) or ((v[0],0) in c and (0,v[1]) in c))
    state=tuple(kind(n,0,0,q) for q in range(4))
    assert all((k,q) in keys for q,k in enumerate(state))
    normalized[n]=state
assert len(normalized)==47 and len(set(normalized.values()))==47
report={'planSHA256':hashlib.sha256(plan_path.read_bytes()).hexdigest(),'connectedGuideComponents':components,
        'guidePorts':ports,'orientedQuarterBasis':len(keys),'rawNeighborhoods':256,'normalizedStates':47,
        'missingQuarterStates':unreachable,'artApproval':False,
        'limits':['Checks geometry guide, not generated silhouette.','Does not cover every two-cell wide phase or visual seams.']}
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
