"""Geometry-only native16 extraction guide; never used as terrain artwork."""
from pathlib import Path
from PIL import Image
import json
p=Path(__file__).parent
plan=json.loads((p/'moss-winding-plan-r2.json').read_text())
plan['schema']='winding-native16-quarter-basis-v1'
plan['logicalCanvas']=[192,192];plan['sourceCellPixels']=16
for sample in plan['samples']:
    sample['quarterRect']=[v//2 for v in sample.pop('wideRect')]
plan['notes']=['Geometry/layout only; keep moss/navy style.',
               'Single native16 terrain bank, eight-pixel quarters, no wide/compact mixing.',
               'Generated texture phase, silhouette and actual Unity are still to be verified.']
(p/'moss-native16-plan-r4.json').write_text(json.dumps(plan,indent=2)+'\n')
mask=Image.open(p/'moss-winding-mask-r2.png').resize((192,192),Image.Resampling.NEAREST)
mask.save(p/'moss-native16-mask-r4.png')
guide=Image.new('RGB',(192,192),'#ff00ff');guide.paste('#203f4c',mask=mask)
guide.resize((1024,1024),Image.Resampling.NEAREST).save(p/'moss-native16-guide-r4.png')
