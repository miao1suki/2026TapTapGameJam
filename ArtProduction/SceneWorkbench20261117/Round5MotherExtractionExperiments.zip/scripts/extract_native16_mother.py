"""Single logical192 mother -> one native16 autotile bank, no wide bank.

Crop/translation/key/edge correction only; never draws foliage. Native grid
is a design target, not a claim that the generator's encoding is pixel-perfect.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,sys,hashlib
from align_quarter_seams import align

p=Path(__file__).parent;src=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False)
plan=json.loads((p/'moss-native16-plan-r4.json').read_text())
raw=Image.open(src).convert('RGBA');im=raw.resize((192,192),Image.Resampling.NEAREST)
def is_key(c):
    r,g,b,a=c
    return r>50 and b>50 and r>g*1.4 and b>g*1.4
im.putdata([(0,0,0,0) if is_key(c) else c[:3]+(255,) for c in im.getdata()])
mask=Image.open(p/'moss-native16-mask-r4.png').convert('L');alpha=im.getchannel('A')
bank={};samples=[]
for sample in plan['samples']:
    k,q=sample['kind'],sample['imageQuadrant'];x,y,w,h=sample['quarterRect'];cx,cy=sample['cell'];cx=cx*16+8;cy=cy*16+8
    points=[(xx,yy,mask.getpixel((xx,yy))>0) for yy in range(cy-14,cy+15,2) for xx in range(cx-14,cx+15,2)
            if 0<=xx<192 and 0<=yy<192]
    offsets=[(dx,dy) for dx in range(-4,5) for dy in range(-4,5)
             if k!='fill' and (k!='horizontal' or dx==0) and (k!='vertical' or dy==0)] or [(0,0)]
    def error(offset):
        dx,dy=offset
        wrong=sum((alpha.getpixel((xx+dx,yy+dy))>127)!=want for xx,yy,want in points
                  if 0<=xx+dx<192 and 0<=yy+dy<192)
        return wrong/len(points)+(abs(dx)+abs(dy))*.0001
    dx,dy=(0,0) if k=='fill' else min(offsets,key=error)
    patch=im.crop((x+dx,y+dy,x+dx+8,y+dy+8));bank[8,k,q]=patch
    colors=list(patch.getdata());green=sum(a>0 and g>b*1.3 and g>r for r,g,b,a in colors)
    soil=sum(a>0 and b>g>r for r,g,b,a in colors)
    samples.append({**sample,'sampleRect':[x+dx,y+dy,8,8],'translation':[dx,dy],
                    'maskMismatch':round(error((dx,dy)),4),'opaque':sum(c[3]>0 for c in colors),'green':green,'soil':soil})
if '--limit-rim' in sys.argv:
    # Clip excess generated moss back to a readable core; retain the generated
    # exterior silhouette and generated soil. This never invents leaf pixels.
    for k in ['outer','vertical','horizontal','inner']:
        for q in range(4):
            patch=bank[8,k,q];core=bank[8,'fill',q]
            for y in range(8):
                for x in range(8):
                    dx=x if q%2==0 else 7-x;dy=y if q<2 else 7-y
                    side=3;vertical=5 if q<2 else 3
                    in_core=(dx>=side and dy>=vertical) if k=='outer' else dx>=side if k=='vertical' else dy>=vertical if k=='horizontal' else ((dx+.5)/side)**2+((dy+.5)/vertical)**2>1
                    if in_core and patch.getpixel((x,y))[3]>0:patch.putpixel((x,y),core.getpixel((x,y)))
seam_report=align(bank) if '--align' in sys.argv else None

def slot_kind(slot,q):
    if slot>=9:return 'inner' if q==((slot-9)^2) else 'fill'
    x,y=slot%3,slot//3;h=not((x==0 and q%2==0) or (x==2 and q%2==1));v=not((y==0 and q<2) or (y==2 and q>=2))
    return 'outer' if not h and not v else 'vertical' if not h else 'horizontal' if not v else 'fill'
sheet=Image.new('RGBA',(208,16))
for slot in range(13):
    for q in range(4):sheet.paste(bank[8,slot_kind(slot,q),q],(slot*16+q%2*8,q//2*8))
sheet.save(out/'MossWindingCompactRaw.png');im.save(out/'MotherNative192.png')
im.resize((576,576),Image.Resampling.NEAREST).save(out/'MotherPreview.png')

neighbors=[(x,y) for y in range(-1,2) for x in range(-1,2) if x or y];states={}
for bits in range(256):
    cells={(0,0)}|{v for i,v in enumerate(neighbors) if bits>>i&1}
    norm=frozenset(v for v in cells if v==(0,0) or not(v[0] and v[1]) or ((v[0],0) in cells and (0,v[1]) in cells))
    def kind(q):
        dx=-1 if q%2==0 else 1;dy=-1 if q<2 else 1;h=(dx,0) in norm;v=(0,dy) in norm;d=(dx,dy) in norm
        return 'outer' if not h and not v else 'vertical' if not h else 'horizontal' if not v else 'fill' if d else 'inner'
    states[norm]=tuple(kind(q) for q in range(4))
assert len(states)==47 and len(set(states.values()))==47
board=Image.new('RGBA',(768,370),'#142331');d=ImageDraw.Draw(board);f=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',14)
d.text((12,8),'原生16候选 · 同一母图 · 47邻接采样预检（不是Unity）',font=f,fill='white')
for i,ks in enumerate(states.values()):
    tile=Image.new('RGBA',(16,16))
    for q,k in enumerate(ks):tile.paste(bank[8,k,q],(q%2*8,q//2*8))
    x=12+i%12*63;y=38+i//12*80;board.alpha_composite(tile.resize((48,48),Image.Resampling.NEAREST),(x,y));d.text((x,y+50),str(i+1),font=f,fill='#a9bcc7')
board.save(out/'Native16NeighborPrecheck.png')
report={'source':src.name,'sourceSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'rawSize':raw.size,'logicalSize':[192,192],
        'nativeCellPixels':16,'wideBank':False,'legalCompactNeighborStates':47,'samples':samples,'compactSeams':seam_report,
        'processing':['Uniform nearest resample to logical192 (generator encoding is not claimed native)',
                      'Magenta decontamination/key, opaque remaining pixels','Local integer alpha registration, no rotation or per-quarter scaling',
                      '8x8 quarter crops, assemble one 13-slot native16 bank'],
        'rimLimit':{'enabled':'--limit-rim' in sys.argv,'top':5,'side':3,'bottom':3,
                    'method':'Clip excessive generated moss to generated core pixels; preserve exterior alpha silhouette. No leaf synthesis.'},
        'artApproved':False,'unityImported':False,'limits':['Corner shape, thickness and actual Unity remain to be reviewed.']}
(out/'extraction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'raw':raw.size,'logical':[192,192],'neighbors':47,'samples':[(s['kind'],s['imageQuadrant'],s['green'],s['soil']) for s in samples]}))
