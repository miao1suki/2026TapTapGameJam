from pathlib import Path
from PIL import Image
import hashlib,json,zipfile,subprocess,re

repo=Path('C:/Users/miao/.codex/worktrees/scene-authoring-redesign/2026TapTap')
task=Path(__file__).resolve().parent.parent
work=task/'work';art=work/'art';out=task/'outputs'
candidate=out/'winding-mixed-only-r6'
production=repo/'ArtProduction/SceneWorkbench20261117'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((repo/'Docs/Developer/Evidence/SceneWorkbench20261117/Round11/validation.json').read_text())
for group in ['sourceSHA256','formalSHA256']:
    for path,expected in previous[group].items():assert sha(repo/path)==expected,(group,path)
protected=['Packages','ProjectSettings','Assets/_Project/Development/LevelEditor/SceneAuthoringShowcase',
           'Assets/_Project/Code/Systems/GridArt/Editor/GridArtWideContour.cs']
assert not subprocess.check_output(['git','diff','HEAD','--',*protected],cwd=repo)
dependencies=json.loads((work/'r6-delivery-dependencies.json').read_text())
assert not dependencies['unexpectedOrMissingReferences']
lab=repo/dependencies['candidate']
for name in ['MossWindingCompactRaw.png','MossWindingWideRaw.png']:
    assert sha(lab/name)==sha(candidate/name),name
for name,size in [('Aqueduct',(1536,864)),('Connections',(1536,1248)),('All47',(1536,864))]:
    assert Image.open(candidate/('Unity'+name+'.png')).size==size,name
    assert sha(candidate/('Unity'+name+'.png'))==sha(repo/'Library/WindingMotherLabR6'/(name+'.png'))
result=repo/'Library/WindingMotherLabR6/result.txt'
assert 'Candidate scenes saved and GPU captures exported.' in result.read_text()
review=Path('C:/Users/miao/AppData/Local/XingZhiCai/ArtWorkflow/reviews/20261118-173952-726.json')
rd=json.loads(review.read_text(encoding='utf-8-sig'))
assert rd['reviewComplete'] and not rd['is_error']
assert rd['imageSHA256']==sha(out/'TopologyAndSeamReviewR6.png')
assert rd['briefSHA256']==sha(art/'mixed-transition-review-r6.txt')
metrics=json.loads((candidate/'unity-sampling-alignment.json').read_text())
assert metrics['compatibleEdgePairs']==30 and metrics['allSampledEdgePairs']==816
assert metrics['changedPatchPixels']==586 and metrics['afterMaxRGBA']==0
items=[]
def add(path,name):
    assert path.is_file(),path
    assert name not in [n for _,n in items],name
    items.append((path,name))
for name in ['align_unity_sampling.py','align_quarter_seams.py','build_mixed_transition_review.py',
             'build_threeway_seam_review.py','mixed-transition-review-r6.txt']:
    add(art/name,('scripts/' if name.endswith('.py') else 'reviews/')+name)
for name in ['collect_r6_delivery.py','r6-delivery-dependencies.json','archive_round12.py']:
    add(work/name,'verification/'+name)
for name in ['MossWindingCompactRaw.png','MossWindingWideRaw.png','MossWindingMotherNative384.png','extraction.json']:
    add(out/'winding-mother-r3b'/name,'baseline-input/'+name)
for name in ['MossWindingCompactRaw.png','MossWindingWideRaw.png','UnityConnections.png']:
    add(out/'winding-mother-r3d'/name,'retained-r3d/'+name)
for path in sorted(candidate.iterdir()):
    if path.is_file():add(path,'candidate-r6/'+path.name)
for path in sorted((repo/'Assets/_Project/Development/LevelEditor/WindingMotherLabR3').glob('*Map.asset')):
    add(path,'sampling-maps/'+path.name)
add(repo/'Assets/_Project/Code/Systems/GridArt/Editor/GridArtWideContour.cs','sampling-code/GridArtWideContour.cs.txt')
add(out/'TopologyAndSeamReviewR6.png','reviews/TopologyAndSeamReviewR6.png')
add(out/'WideInsetDetailComparison.png','reviews/WideInsetDetailComparison.png')
add(review,'reviews/'+review.name)
add(result,'verification/unity-result.txt')
report={
 'schema':'winding-mother-mixed-boundary-v1','unity':'6000.3.12f1','artApproved':False,
 'referenceScope':'Two user images constrain continuous mother topology only, not style. Moss/navy retained.',
 'source':{'name':'moss-winding-mother-r3.png','sha256':sha(art/'moss-winding-mother-r3.png'),
           'archive':'Round5MotherExtractionExperiments.zip','archiveSHA256':sha(production/'Round5MotherExtractionExperiments.zip'),
           'sourceDimensions':[1254,1254],'logicalProcessingTarget':[384,384],
           'nativePixelScaleVerified':False,'newPaidGenerationThisContinuation':False},
 'method':'Existing generated mother pixels only; local premultiplied edge correction and one-pixel feather at mixed-width transitions, plus magenta decontamination. No generated corner requests and no procedural foliage drawing.',
 'boundedSampling':{'patches':214,'allEdgePairs':816,'mixedEdgePairs':30,'changedPixelsVsR3d':586,'maxSelectedEdgeDifferenceAfter':0},
 'gpu':'Three actual Camera.Render captures from independently saved Scene/Map/Ownership/Palette copies. Not a software preview.',
 'editableDelivery':dependencies['candidate'],
 'sceneFiles':['Aqueduct.unity','Connections.unity','All47.unity'],
 'dependencyFiles':dependencies['newAssetAndMetaFiles'],
 'serializationFormatting':'Removed only the trailing space of empty m_LockedProperties in 97 newly generated candidate materials. No field value changed.',
 'claude':{'model':list(rd['modelUsage']),'review':review.name,'complete':True,
           'decision':'Keep A/r3d as baseline; B/r6 conditional continuation only after dark groove correction; C/r5c rework.'},
 'testReuse':{'round':'11','relatedEditMode':previous['tests'],'sourceHashesVerifiedUnchanged':True},
 'protectedPathsUnchanged':protected,'formalSHA256':previous['formalSHA256'],
 'reproduction':[
  'Source extraction steps are in Round4/5 archives. baseline-input contains the exact r3b atlas inputs for this bounded correction.',
  'python scripts/align_unity_sampling.py baseline-input <fresh-output> sampling-maps sampling-code/GridArtWideContour.cs.txt --mixed-only',
  'Unity -batchmode -projectPath <project> -executeMethod Project.LevelEditor.Editor.SceneWorkbenchWindingLab.CreateFromCommandLine -windingArtInput <fresh-output> -windingLabName <new-unique-name> -logFile <log>. Use graphics; do not pass -nographics. Refuses an existing lab folder.'
 ],
 'limitations':[
  'Art is not approved. Current candidate still has a horizontal dark groove and periodic grass teeth. Do not replace the retained baseline or committed showcase automatically.',
  'Edge equality covers only the listed maps and mixed-width pairs, not exhaustive two-cell distance/parity combinations or aesthetic continuity.',
  'Extraction unityImported:false flags predate actual imports; the actual captures and editable assets are delivered here.',
  'The 384 logical target is local nearest-neighbor processing, not verified generator-native pixel scale.',
  'No new native foreground UX validation, complete playable level, Android build, or performance claim is made.'
 ]}
manifest={name:{'sha256':sha(path),'bytes':path.stat().st_size} for path,name in items}
archive=production/'Round6MixedBoundarySources.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path,name in items:z.write(path,name)
    z.writestr('CandidateRun.json',json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    z.writestr('Manifest.json',json.dumps(manifest,indent=2)+'\n')
forbidden={'api_key','apikey','authorization','auth_token','access_token','refresh_token','password','secret'}
token=re.compile(r'(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|Bearer [A-Za-z0-9_.-]{20,})')
def check_keys(value):
    if isinstance(value,dict):
        for key,item in value.items():assert key.lower() not in forbidden,key;check_keys(item)
    elif isinstance(value,list):
        for item in value:check_keys(item)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,info in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256'],name
    for name in z.namelist():
        assert not any(part in ['..','Library','Logs','Temp'] for part in Path(name).parts),name
        if name.endswith(('.json','.py','.txt','.asset')):
            value=z.read(name).decode('utf-8-sig');assert not token.search(value),name
            if name.endswith('.json'):check_keys(json.loads(value))
summary={'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'hashedEntries':len(items),
         'crcAndHashesVerified':True,'credentialScanPassed':True,'artApproved':False,
         'editableCandidate':dependencies['candidate'],'newAssetAndMetaFiles':dependencies['newAssetAndMetaFiles'],
         'missingReferences':0,'retainedBaseline':'r3d','currentCandidate':'r6 conditional continuation, dark groove still requires work',
         'sourceAndFormalHashesVerifiedUnchanged':True,'relatedTestsReused':previous['tests'],
         'details':'CandidateRun.json, verification/r6-delivery-dependencies.json and Manifest.json in archive'}
(production/'Round6Provenance.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
