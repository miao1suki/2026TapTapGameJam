"""Read-only YAML dependency closure for this exact candidate's new assets.

Existing tracked dependencies are reused. Unexpected untracked dependencies
fail instead of broad-staging older experimental labs.
"""
from pathlib import Path
import subprocess,re,json
repo=Path('C:/Users/miao/.codex/worktrees/scene-authoring-redesign/2026TapTap')
root='Assets/_Project/Development/LevelEditor/WindingMotherLabR6'
baseline='1ee86735'
tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',baseline],cwd=repo,text=True).splitlines())
guid_paths={}
for meta in (repo/'Assets').rglob('*.meta'):
    match=re.search(r'^guid: ([0-9a-f]{32})$',meta.read_text(encoding='utf-8-sig'),re.M)
    if match:guid_paths[match[1]]=meta.relative_to(repo).as_posix()[:-5]
map_pairs=[]
for meta in (repo/root).glob('*Map.asset.meta'):
    map_guid=re.search(r'^guid: ([0-9a-f]{32})$',meta.read_text(),re.M)[1]
    scene_guid=re.search(r'^  ownerSceneGuid: ([0-9a-f]{32})$',Path(str(meta)[:-5]).read_text(),re.M)[1]
    scene_meta=repo/(guid_paths[scene_guid]+'.meta')
    assert scene_meta.parent==repo/root,scene_meta
    map_pairs.append({'sceneGuid':scene_guid,'mapGuid':map_guid})
map_guids=[pair['mapGuid'] for pair in map_pairs]
allowed=[root]+['Assets/_Project/Art/Generated/GridArt/'+pair['sceneGuid']+'/'+pair['mapGuid'] for pair in map_pairs]
selected=set();queue=[p.relative_to(repo).as_posix() for p in (repo/root).rglob('*') if p.is_file() and not p.name.endswith('.meta')]
missing=[];package_refs=[]
while queue:
    path=queue.pop()
    if path in selected or path in tracked:continue
    assert any(path==a or path.startswith(a+'/') for a in allowed),'Unexpected untracked dependency: '+path
    asset=repo/path;assert asset.is_file(),path
    selected.add(path);assert (repo/(path+'.meta')).is_file(),path
    selected.add(path+'.meta')
    for parent in asset.parents:
        if parent==repo/'Assets':break
        rel=parent.relative_to(repo).as_posix()+'.meta'
        if rel not in tracked:
            assert (repo/rel).is_file(),rel
            selected.add(rel)
    if asset.suffix in ['.unity','.asset','.prefab','.mat']:
        for guid in set(re.findall(r'guid: ([0-9a-f]{32})',asset.read_text(encoding='utf-8-sig'))):
            target=guid_paths.get(guid)
            if target is None:
                if not guid.startswith('0000000000000000'):
                    # A shipped URP default material is a package dependency, not a new Assets file.
                    package_meta=repo/'Library/PackageCache/com.unity.render-pipelines.universal@fd0c0d56fb49/Runtime/Materials/Sprite-Lit-Default.mat.meta'
                    if package_meta.is_file() and re.search(r'^guid: '+guid+'$',package_meta.read_text(),re.M):
                        package_refs.append({'source':path,'guid':guid,'packageAsset':'Packages/com.unity.render-pipelines.universal/Runtime/Materials/Sprite-Lit-Default.mat'})
                    else:missing.append({'source':path,'guid':guid})
            elif (repo/target).is_file():queue.append(target)
assert not missing,missing
paths=sorted(selected)
out=Path(__file__).with_name('r6-delivery-paths.txt');out.write_text('\n'.join(paths)+'\n')
report={'baselineCommit':baseline,'candidate':root,'newAssetAndMetaFiles':len(paths),'totalBytes':sum((repo/p).stat().st_size for p in paths),
        'mapGuids':map_guids,'generatedSceneMapPairs':map_pairs,'packageReferences':package_refs,'unexpectedOrMissingReferences':missing,'paths':paths,
        'limitations':['YAML GUID closure is not independent Unity import validation; actual candidate GPU runs are archived separately.']}
Path(__file__).with_name('r6-delivery-dependencies.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['paths','limitations']}))
