from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).resolve().parents[2]/'outputs'
folders=['winding-mother-r3d','winding-mixed-only-r6','winding-r3-wideinset-r5c']
labels=['A：r3d 原宽/紧凑混接','B：r6 仅30类交界修正','C：r5c 同宽源，窄条取内侧']
board=Image.new('RGB',(1530,700),'#142331');d=ImageDraw.Draw(board);f=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',16)
for i,(folder,label) in enumerate(zip(folders,labels)):
    x=i*510+8;im=Image.open(p/folder/'UnityConnections.png')
    d.text((x,8),label,font=f,fill='white')
    board.paste(im.crop((524,1014,684,1106)).resize((480,276),Image.Resampling.NEAREST),(x,42))
    board.paste(im.crop((420,150,660,270)).resize((480,240),Image.Resampling.NEAREST),(x,350))
    board.paste(im.crop((1200,180,1270,245)).resize((105,98),Image.Resampling.NEAREST),(x+350,595))
d.text((8,325),'同机位真实Unity裁片：孔洞交界3倍；下方窄条2倍；右下单格1.5倍。无美术重绘。',font=f,fill='#b6c9d5')
board.save(p/'TopologyAndSeamReviewR6.png')
