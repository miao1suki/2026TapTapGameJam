from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops
import shutil,json
p=Path(__file__).resolve().parents[2];o=p/'outputs';out=o/'winding-mixed-only-r6'
run=Path('C:/Users/miao/.codex/worktrees/scene-authoring-redesign/2026TapTap/Library/WindingMotherLabR6')
for name in ['Aqueduct','Connections','All47']:shutil.copy2(run/(name+'.png'),out/('Unity'+name+'.png'))
before=Image.open(o/'winding-mother-r3d/UnityConnections.png').convert('RGB')
after=Image.open(out/'UnityConnections.png').convert('RGB')
board=Image.new('RGB',(1100,760),'#142331');d=ImageDraw.Draw(board);f=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',17)
d.text((12,8),'左：r3d　原宽/紧凑交界',font=f,fill='white');d.text((562,8),'右：r6　只修30类混接边界',font=f,fill='white')
context=(64,998,700,1126);detail=(524,1014,684,1106)
for x,im in [(12,before),(562,after)]:
    board.paste(im.crop(context).resize((530,107),Image.Resampling.NEAREST),(x,40))
    board.paste(im.crop(detail).resize((480,276),Image.Resampling.NEAREST),(x,180))
d.text((12,151),'同一Unity相机的长条孔洞原图裁切；下方3倍最近邻细节',font=f,fill='#b6c9d5')
d.text((12,470),'其余连接实际GPU缩略图；没有重绘地形',font=f,fill='white')
board.paste(before.resize((330,268),Image.Resampling.NEAREST),(12,496))
board.paste(after.resize((330,268),Image.Resampling.NEAREST),(562,496))
board.save(out/'MixedTransitionComparison.png')
Image.open(out/'UnityAqueduct.png').resize((768,432),Image.Resampling.NEAREST).save(out/'UnityAqueductPreview.png')
delta={}
for name in ['MossWindingCompactRaw.png','MossWindingWideRaw.png']:
    a=Image.open(o/'winding-mother-r3d'/name).convert('RGBA');b=Image.open(out/name).convert('RGBA')
    delta[name]={'pixels':a.width*a.height,'changedRGBA':sum(x!=y for x,y in zip(a.getdata(),b.getdata()))}
(out/'baseline-delta.json').write_text(json.dumps(delta,indent=2)+'\n');print(json.dumps(delta))
