from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).parent
ASSETS=Path(r'C:\Users\miao\.codex\worktrees\scene-authoring-redesign\2026TapTap\Assets/_Project/Development/LevelEditor/SceneAuthoringShowcase')
OUT=ROOT.parent.parent/'outputs'
source=Image.open(ROOT/'moss-terrain-half-safe-r4.png'); corners=Image.open(ROOT/'moss-inner-wide-r2.png')
compact=Image.open(ROOT/'moss-compact-r1.png')
def tile(im,x,y,n,size):
 w,h=im.size
 im=im.crop((round(x*w/n)+2,round(y*h/n)+2,round((x+1)*w/n)-2,round((y+1)*h/n)-2)).convert('RGBA').resize((size,size),Image.Resampling.NEAREST)
 pixels=[]
 for r,g,b,a in im.getdata():
  if r>150 and b>130 and g<110:a=0
  if r<35 and g<60 and b<100:r,g,b=int(14+(r-14)*.35),int(31+(g-31)*.35),int(47+(b-47)*.35)
  pixels.append((r,g,b,a))
 im.putdata(pixels);return im
slots=[(0,0),(1,0),(2,0),(0,1),(1,1),(3,1),(0,2),(1,2),(3,2)]
wide=[tile(source,x,y,4,32) for x,y in slots]+[tile(corners,x,y,2,32) for x,y in [(0,0),(1,0),(0,1),(1,1)]]
small=[tile(compact,x,y,4,16) for x,y in [(0,0),(1,0),(2,0),(0,1),(1,1),(2,1),(0,2),(1,2),(2,2),(0,3),(1,3),(2,3),(3,3)]]
for name,tiles,size in [('MossTerrainBands',small,16),('MossTerrainWide',wide,32)]:
 atlas=Image.new('RGBA',(size*13,size))
 for i,im in enumerate(tiles):atlas.paste(im,(i*size,0))
 atlas.save(ASSETS/(name+'.png'))

def pick(cells,x,y,q):
 same=lambda dx,dy:(x+dx,y+dy) in cells
 def air(dx,dy):
  return next((d for d in (1,2) if not same(dx*d,dy*d)),0)
 l,r,b,t=air(-1,0),air(1,0),air(0,-1),air(0,1)
 qx,qy=q%2,q//2;cx,cy=qx*.5+.25,qy*.5+.25
 if l==r==1 or t==b==1:
  dx=-1 if qx==0 else 1;dy=-1 if qy==0 else 1
  h,v,d=same(dx,0),same(0,dy),same(dx,dy);sx=0 if qx==0 else 2;sy=2 if qy==0 else 0
  slot=sy*3+sx if not h and not v else 3+sx if not h else sy*3+1 if not v else 4 if d else 9+q
  return small[slot].crop((qx*8,(1-qy)*8,qx*8+8,(1-qy)*8+8))
 left=l>0 and (r==0 or l-1+cx<=r-cx);bottom=b>0 and (t==0 or b-1+cy<=t-cy)
 h=l if left else r;v=b if bottom else t
 sx=x%2*16+qx*8;sy=y%2*16+qy*8;slot=4
 if h:sx=(l-1)*16+qx*8 if left else 32-r*16+qx*8
 if v:sy=(b-1)*16+qy*8 if bottom else 32-t*16+qy*8
 if h and v:slot=(2 if bottom else 0)*3+(0 if left else 2)
 elif h:slot=3 if left else 5
 elif v:slot=7 if bottom else 1
 if True:
  cardinal=min([v for v in [l-1+cx if l else 999,r-cx if r else 999,b-1+cy if b else 999,t-cy if t else 999]])
  nearest=cardinal**2
  for dy in range(-2,3):
   for dx in range(-2,3):
    if dx==0 or dy==0 or same(dx,dy):continue
    ddx=-dx-1+cx if dx<0 else dx-cx;ddy=-dy-1+cy if dy<0 else dy-cy;dist=ddx**2+ddy**2
    if dist>=nearest:continue
    nearest=dist;slot=9+(0 if dx<0 else 1)+(0 if dy<0 else 2)
    sx=(-dx-1)*16+qx*8 if dx<0 else 32-dx*16+qx*8
    sy=(-dy-1)*16+qy*8 if dy<0 else 32-dy*16+qy*8
 return wide[slot].crop((sx,32-sy-8,sx+8,32-sy))
def render(cells):
 xmin=min(x for x,y in cells);ymax=max(y for x,y in cells);xmax=max(x for x,y in cells);ymin=min(y for x,y in cells)
 im=Image.new('RGBA',((xmax-xmin+3)*16,(ymax-ymin+3)*16),'#1A2A36')
 for x,y in cells:
  for q in range(4):im.alpha_composite(pick(cells,x,y,q),((x-xmin+1)*16+q%2*8,(ymax-y+1)*16+(1-q//2)*8))
 return im
rect=lambda w,h:{(x,y) for x in range(w) for y in range(h)}
shapes=[('实体',rect(8,5)),('一格横条',rect(8,1)),('一格竖柱',rect(1,6)),('孤立格',{(0,0)}),('孔洞',rect(8,6)-{(x,y) for x in range(2,6) for y in range(2,4)}),('L 与凹角',{(x,y) for x,y in rect(8,5) if x<2 or y<2}),('T 连接',{(x,y) for x,y in rect(8,5) if y>2 or 3<=x<=4}),('十字连接',{(x,y) for x,y in rect(7,7) if x in (2,3) or y in (2,3)}),('阶梯',{(x,y) for x,y in rect(8,5) if y<=x//2}),('缺口',{(x,y) for x,y in rect(8,6) if not(2<=x<=5 and y>=2)}),('斜角不相连',{(0,0),(1,1),(2,2)}),('负坐标',{(x-5,y-7) for x,y in rect(5,4) if not(x==2 and y==2)})]
qa=Image.new('RGBA',(1536,1240),'#141A22');draw=ImageDraw.Draw(qa);font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',20)
for i,(label,cells) in enumerate(shapes):
 x=i%4*384;y=i//4*340;draw.text((x+18,y+12),label,font=font,fill='white');im=render(cells);scale=min(3,350//im.width,278//im.height);qa.alpha_composite(im.resize((im.width*scale,im.height*scale),Image.Resampling.NEAREST),(x+18,y+48))
draw.text((18,1030),'宽源片 32px，保持16px/格；x31/32跨分块源像素预检，待Unity核对',font=font,fill='white')
im=render({(x,y) for x in range(-2,35) for y in range(4) if not(29<=x<=32 and y in (1,2))});qa.alpha_composite(im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST),(18,1072));qa.save(OUT/'autotile-wide-qa-r11.png')
