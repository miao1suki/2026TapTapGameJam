from pathlib import Path
import sys
from collections import deque
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).parent
OUT=ROOT.parent.parent/'outputs'
assets=Path(r'C:\Users\miao\.codex\worktrees\scene-authoring-redesign\2026TapTap\Assets\_Project\Development\LevelEditor\SceneAuthoringShowcase')
version=int(sys.argv[1]) if len(sys.argv)>1 else 3
source=Image.open(ROOT/f'moss-compact-thick-r{version}.png')
positions=[(0,0),(1,0),(2,0),(0,1),(1,1),(2,1),(0,2),(1,2),(2,2),(0,3),(1,3),(2,3),(3,3)]
small=[]
for x,y in positions:
    w,h=source.size
    tile=source.crop((round(x*w/4)+2,round(y*h/4)+2,round((x+1)*w/4)-2,round((y+1)*h/4)-2)).convert('RGBA').resize((16,16),Image.Resampling.NEAREST)
    pixels=[]
    for r,g,b,a in tile.getdata():
        if r>150 and b>130 and g<110:a=0
        if r<35 and g<60 and b<100:r,g,b=int(14+(r-14)*.35),int(31+(g-31)*.35),int(47+(b-47)*.35)
        pixels.append((r,g,b,a))
    tile.putdata(pixels)
    if version == 4 and (x,y) not in [(1,1),(3,0),(3,1),(3,2)] and y<3:
        # Recover the outside matte only, from this tile's exposed sides.
        # The generated connected teal/green band separates it from the core.
        sides=[]
        if x==0:sides += [(0,i) for i in range(16)]
        if x==2:sides += [(15,i) for i in range(16)]
        if y==0:sides += [(i,0) for i in range(16)]
        if y==2:sides += [(i,15) for i in range(16)]
        pending=deque(sides);seen=set()
        while pending:
            px,py=pending.popleft()
            if (px,py) in seen or not (0<=px<16 and 0<=py<16):continue
            seen.add((px,py));r,g,b,a=tile.getpixel((px,py))
            if not (a==0 or r<35 and g<60 and b<100):continue
            tile.putpixel((px,py),(r,g,b,0))
            pending.extend([(px-1,py),(px+1,py),(px,py-1),(px,py+1)])
    small.append(tile)
atlas=Image.new('RGBA',(13*16,16))
for i,tile in enumerate(small):atlas.paste(tile,(i*16,0))
atlas.save(ROOT/f'MossTerrainBands-r{version}.png')
wide_atlas=Image.open(assets/'MossTerrainWide.png')
wide=[wide_atlas.crop((i*32,0,i*32+32,32)) for i in range(13)]
code=(ROOT/'prepare_wide.py').read_text(encoding='utf-8')
code=code[code.index('def pick('):].replace("'autotile-wide-qa-r11.png'",f"'autotile-compact-r{version}-precheck.png'")
exec(code)
