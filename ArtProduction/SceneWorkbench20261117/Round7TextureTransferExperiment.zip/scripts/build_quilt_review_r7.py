from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import shutil
task=Path(__file__).resolve().parents[2];out=task/'outputs'
repo=Path('C:/Users/miao/.codex/worktrees/scene-authoring-redesign/2026TapTap')
dest=out/'winding-source-quilt-r7'
for name in ['Aqueduct','Connections','All47']:
    shutil.copy2(repo/'Library/WindingMotherLabR7'/(name+'.png'),dest/('Unity'+name+'.png'))
Image.open(dest/'UnityAqueduct.png').resize((768,432),Image.Resampling.NEAREST).save(dest/'UnityAqueductPreview.png')
board=Image.new('RGB',(1530,700),'#142331');d=ImageDraw.Draw(board);f=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',16)
for i,(folder,label) in enumerate(zip(['winding-mother-r3d','winding-mixed-only-r6','winding-source-quilt-r7'],
    ['A：r3d 基线','B：r6 校正交界','C：r7 同源草皮补片'])):
    x=i*510+8;im=Image.open(out/folder/'UnityConnections.png')
    d.text((x,8),label,font=f,fill='white')
    board.paste(im.crop((524,1014,684,1106)).resize((480,276),Image.Resampling.NEAREST),(x,42))
    board.paste(im.crop((420,150,660,270)).resize((480,240),Image.Resampling.NEAREST),(x,350))
d.text((8,325),'同机位实际Unity：孔洞连接3倍、单格窄条2倍。C保留alpha/原草边/宽片，只替换紧凑蓝芯。',font=f,fill='#b6c9d5')
board.save(out/'TopologyAndQuiltReviewR7.png')
print('Copied three actual GPU captures; built same-coordinate review.')
