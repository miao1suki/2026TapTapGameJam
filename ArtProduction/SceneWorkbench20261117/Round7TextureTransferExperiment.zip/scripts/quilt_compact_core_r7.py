"""Candidate-only native-pixel texture transfer from the SAME generated mother.

Keep every existing alpha and moss pixel. Replace only blue compact soil with
opaque 8x8 foliage samples cropped from the mother; no painting or recoloring.
Wide contour, density, grid scale and production sampler remain unchanged.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,sys,shutil
src,out=map(Path,sys.argv[1:3]);out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mother=Image.open(src/'MossWindingMotherNative384.png').convert('RGBA')
green=lambda p:p[3]==255 and p[1]>p[0] and p[1]>p[2]*1.3
candidates=[]
for y in range(0,mother.height-7,2):
    for x in range(0,mother.width-7,2):
        patch=mother.crop((x,y,x+8,y+8));colors=list(patch.getdata())
        if not all(map(green,colors)):continue
        diversity=len(set(colors))
        if not 8<=diversity<=40:continue
        # Moderate source diversity rather than the brightest flat patch.
        score=-abs(diversity-22)
        candidates.append((score,x,y))
chosen=[]
for score,x,y in sorted(candidates,reverse=True):
    if all(abs(x-a)+abs(y-b)>=48 for a,b in chosen):chosen.append((x,y))
    if len(chosen)==4:break
assert len(chosen)==4,'Insufficient distinct generated foliage crops'
donors=[mother.crop((x,y,x+8,y+8)) for x,y in chosen]
before=Image.open(src/'MossWindingCompactRaw.png').convert('RGBA');compact=before.copy()
changed=0
for y in range(compact.height):
    for x in range(compact.width):
        old=before.getpixel((x,y))
        if old[3]>0 and old[2]>old[1] and old[1]>old[0]:
            q=(x%16)//8+(y//8)*2
            rgb=donors[q].getpixel((x%8,y%8))[:3]
            compact.putpixel((x,y),rgb+(old[3],));changed+=1
assert list(compact.getchannel('A').getdata())==list(before.getchannel('A').getdata())
compact.save(out/'MossWindingCompactRaw.png')
for name in ['MossWindingWideRaw.png','MossWindingMotherNative384.png']:shutil.copy2(src/name,out/name)
report={'method':'Source texture transfer into compact blue core only; four whole 8px crops from the same mother, no scaling/color synthesis.',
 'baseline':'r3d','motherSHA256':sha(src/'MossWindingMotherNative384.png'),'sourcePatches':[[x,y,8,8] for x,y in chosen],
 'changedCompactPixels':changed,'alphaUnchanged':True,'wideAtlasSHA256':sha(src/'MossWindingWideRaw.png'),
 'artApproved':False,'unityImported':False,'limits':['May expose new wide/compact joins or periodic texture; requires actual GPU review.']}
(out/'texture-transfer.json').write_text(json.dumps(report,indent=2)+'\n')
board=Image.new('RGB',(1000,400),'#172633');d=ImageDraw.Draw(board);font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',16)
d.text((12,8),'r7 源纹理补片实验：只替换紧凑片蓝土芯；保留alpha、原草边和宽片。不是Unity图。',font=font,fill='white')
for i,im in enumerate([before,compact]):
    bg=Image.new('RGBA',im.size,'#172633');bg.alpha_composite(im)
    board.paste(bg.convert('RGB').resize((832,64),Image.Resampling.NEAREST),(12,55+i*105))
    d.text((12,125+i*105),'原r3d' if i==0 else 'r7 纹理转移候选',font=font,fill='white')
for q,patch in enumerate(donors):
    board.paste(patch.resize((64,64),Image.Resampling.NEAREST),(12+q*200,270))
    d.text((12+q*200,342),str(chosen[q]),font=font,fill='white')
board.save(out/'SourcePatchReview.png')
print(json.dumps(report))
