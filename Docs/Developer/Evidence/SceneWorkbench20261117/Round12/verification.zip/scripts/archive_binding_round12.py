from pathlib import Path
import hashlib,json,zipfile,subprocess,xml.etree.ElementTree as ET,re
from datetime import datetime,timezone
repo=Path('C:/Users/miao/.codex/worktrees/scene-authoring-redesign/2026TapTap')
task=Path(__file__).resolve().parent.parent;work=task/'work';out=task/'outputs'
evidence=repo/'Docs/Developer/Evidence/SceneWorkbench20261117/Round12'
production=repo/'ArtProduction/SceneWorkbench20261117'
evidence.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((repo/'Docs/Developer/Evidence/SceneWorkbench20261117/Round11/validation.json').read_text())
for name,expected in baseline['formalSHA256'].items():assert sha(repo/name)==expected,name
protected=['Packages','ProjectSettings','Assets/_Project/Development/LevelEditor/SceneAuthoringShowcase',
 'Assets/_Project/Code/Systems/GridArt/Editor/GridArtWideContour.cs']
assert not subprocess.check_output(['git','diff','HEAD','--',*protected],cwd=repo)
test=ET.parse(work/'ui-art-tests-r36.xml').getroot();assert test.attrib['passed']=='151' and test.attrib['failed']=='0'
end=datetime.strptime(test.attrib['end-time'],'%Y-%m-%d %H:%M:%SZ').replace(tzinfo=timezone.utc).timestamp()
sources=[
 'Assets/_Project/Development/LevelEditor/Orpheus0829/Editor/SceneLevelEditorOverlay.cs',
 'Assets/_Project/Development/LevelEditor/Orpheus0829/Editor/SceneObjectAuthoring.cs',
 'Assets/_Project/Development/LevelEditor/Orpheus0829/Editor/SceneWorkbenchAudit.cs',
 'Assets/_Project/Development/LevelEditor/SceneAuthoringTests/SceneWorkbenchTests.cs']
for name in sources:assert (repo/name).stat().st_mtime<end,name+' modified after test completion'
forbidden={'api_key','apikey','authorization','auth_token','access_token','refresh_token','password','secret'}
token=re.compile(r'(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|Bearer [A-Za-z0-9_.-]{20,})')
def check_keys(value):
 if isinstance(value,dict):
  for key,item in value.items():assert key.lower() not in forbidden,key;check_keys(item)
 elif isinstance(value,list):
  for item in value:check_keys(item)
def archive(path,items,report):
 manifest={name:{'sha256':sha(p),'bytes':p.stat().st_size} for p,name in items}
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for p,name in items:assert p.is_file();z.write(p,name)
  z.writestr('Report.json',json.dumps(report,ensure_ascii=False,indent=2)+'\n')
  z.writestr('Manifest.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  for name,info in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256'],name
  for name in z.namelist():
   assert '..' not in Path(name).parts,name
   if name.endswith(('.json','.py','.xml','.txt')):
    value=z.read(name).decode('utf-8-sig');assert not token.search(value),name
    if name.endswith('.json'):check_keys(json.loads(value))
 return {'file':path.name,'sha256':sha(path),'bytes':path.stat().st_size,'hashedEntries':len(items),'crcAndHashesVerified':True,'credentialScanPassed':True}
report={
 'unity':'6000.3.12f1','baselineCommit':'9685db34',
 'tests':{k:test.attrib[k] for k in ['total','passed','failed','skipped','duration']},
 'sourceSHA256':{p:sha(repo/p) for p in sources},'formalSHA256':baseline['formalSHA256'],
 'bindingUI':'GameObject fields plus use-current-selection buttons. Author-root selection, typed pair resolution, invalid/already-bound disabled. Binding fold precedes component Inspector.',
 'bindingSafety':'Door reassignment records previous door, target door and button together; prefab overrides recorded. Identical bindings return before Undo/dirty writes. Invalid mechanism pairs rejected before opening an Undo group.',
 'coverage':['Attached UI Toolkit pointer gestures for both use-selection buttons; artwork child resolves to author root; target survives selection change.',
  'Binding fields and buttons fit actual 330/380/420px panel layouts; endpoint selection/preflight preserves serialized data and Undo history.',
  'Door/button, signal platform, crank platform and mount pair inference; cross-scene/reversed/self pairs rejected.',
  'One Undo/Redo restores all three door reassignment objects; repeat binding is a zero operation.'],
 'testHarness':{'r34':'26/26 targeted tests passed, 4.7077537s.',
  'r35':'150/151, old editable-layer-default failed its combined map/Undo check. The old diagnostic did not distinguish the two conditions.',
  'r36':'151/151 after settling native selection recording at visual-fixture teardown. No product code changed between r35 and r36; root cause not independently proven by that rerun alone.'},
 'nativeRound12':{'status':'Partial; physical Escape stopped Computer Use. No further foreground input authorized by the continuation.',
  'observed':'Native authoring enable and Scene door selection worked. Binding expansion outcome was inconclusive with competing foreground activity.',
  'observer':'Independent observer remained sceneDirty=False, objects=368, mapDirty=False, revision=3, cells=388, hash cca62cbc0ce9f8eee74711a2d0dfe5ed.',
  'screenshots':'No new screenshots archived; unrelated foreground content excluded.'},
 'protectedPathsUnchanged':protected,
 'notVerified':['Complete native binding journey and save/reopen; all-mode native click isolation; light skin; domain reload session; full game or Android build.']}
items=[(work/name,'tests/'+name) for name in ['ui-tests-r34.xml','ui-art-tests-r35.xml','ui-art-tests-r36.xml']]
observer=work/'round12-native-observer.txt';observer.write_text((repo/'Library/SceneWorkbenchUIAudit.txt').read_text())
items.append((observer,'native-observer.txt'));items.append((Path(__file__),'scripts/archive_binding_round12.py'))
verification=archive(evidence/'verification.zip',items,report)
(evidence/'validation.json').write_text(json.dumps({**report,'verification':verification},ensure_ascii=False,indent=2)+'\n')
candidate=out/'winding-source-quilt-r7';mother=out/'winding-mother-r3d'
art_items=[(work/'art'/name,'scripts/'+name) for name in ['quilt_compact_core_r7.py','build_quilt_review_r7.py']]
for name in ['MossWindingCompactRaw.png','MossWindingWideRaw.png','MossWindingMotherNative384.png']:
 art_items.append((mother/name,'baseline-r3d/'+name))
for p in candidate.iterdir():
 if p.is_file():art_items.append((p,'candidate-r7/'+p.name))
art_items.append((out/'TopologyAndQuiltReviewR7.png','TopologyAndQuiltReviewR7.png'))
for name in ['Aqueduct','Connections','All47']:
 assert sha(candidate/('Unity'+name+'.png'))==sha(repo/'Library/WindingMotherLabR7'/(name+'.png'))
art_items.append((repo/'Library/WindingMotherLabR7/result.txt','unity-result.txt'))
art_report={'artApproved':False,'referenceScope':'User images constrain mother topology only. Moss/navy style retained.',
 'source':'Same r3 mother; no new paid generation. Exact baseline input is archived here. Raw source provenance is in Round4/5 archives.',
 'processing':json.loads((candidate/'texture-transfer.json').read_text()),
 'methodLimit':'Destination mask selects blue soil pixels, then copies source foliage RGB at native pixel scale. This is texture compositing, not a new intact drawing or layered source artwork.',
 'gpu':'Three actual Unity Camera.Render outputs; same production sampler. Source and output atlases were imported in an independent local lab.',
 'status':'Dark navy groove is reduced in inspected crop; periodic stitch-like green lines remain. Progress experiment only; no new complete Claude review or aesthetic approval.',
 'editableDelivery':'r7 lab remains local. Existing committed r6 editable scenes and original showcase remain unchanged.',
 'reproduction':['python scripts/quilt_compact_core_r7.py baseline-r3d <fresh-output>',
  'Unity -batchmode -projectPath <isolated-project> -executeMethod Project.LevelEditor.Editor.SceneWorkbenchWindingLab.CreateFromCommandLine -windingArtInput <fresh-output> -windingLabName <fresh-lab-name> -logFile <log>. Use graphics; refuses an existing lab.'],
 'limits':['Alpha and wide atlas unchanged; this does not prove joins are visually continuous.','1254 source -> 384 processing target, not verified native generator pixel scale.','Does not replace original showcase or retained r3d baseline.']}
art_archive=archive(production/'Round7TextureTransferExperiment.zip',art_items,art_report)
(production/'Round7Provenance.json').write_text(json.dumps({**art_archive,'artApproved':False,'status':art_report['status']},indent=2)+'\n')
print(json.dumps({'verification':verification,'artArchive':art_archive,'tests':report['tests'],'formalHashesUnchanged':True}))
